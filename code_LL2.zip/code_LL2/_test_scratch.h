/////////////////////////////////////////////////////////////////////////////
//
//  _test_scratch.h
//
// Created on: 2024.03.20
// Author: Gabriel Aguirre Ollinger
//
/////////////////////////////////////////////////////////////////////////////

#ifndef CODE_LL2__TEST_SCRATCH_H_
#define CODE_LL2__TEST_SCRATCH_H_

#include <_std_c.h>
#include <nml.h>
#include <nml_util.h>
#include <nml_ref_based.h>

void test_scratch();

#endif
