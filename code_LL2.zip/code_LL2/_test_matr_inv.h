/////////////////////////////////////////////////////////////////////////////
//
//  _test_matr_inv.h
//
// Created on: 2024.03.20
// Author: Gabriel Aguirre Ollinger
//
/////////////////////////////////////////////////////////////////////////////

#ifndef CODE_LL2__TEST_MATR_INV_H_
#define CODE_LL2__TEST_MATR_INV_H_

#include <_std_c.h>
#include <nml.h>
#include <nml_util.h>
#include <nml_ref_based.h>

void test_matr_inv();

#endif /* CODE_LL2__TEST_MATR_INV_H_ */
